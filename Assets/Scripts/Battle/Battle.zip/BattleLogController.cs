using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class BattleLogController : MonoBehaviour
{
    [Header("Battle Log UI")]
    [SerializeField] private TMP_Text battleLogText;

    [Header("Popup Log UI")]
    [SerializeField] private TMP_Text popupLogText;
    [SerializeField] private ScrollRect popupLogScrollRect;

    [Header("Colors")]
    [SerializeField] private string unitNameColor = "#817F7F";
    [SerializeField] private string defaultTextColor = "#FFFFFF";
    [SerializeField] private string damageColor = "#DA7332";
    [SerializeField] private string healColor = "#0EE01C";
    [SerializeField] private string buffColor = "#4D4D4D";
    [SerializeField] private string turnColor = "#FFD966";

    private string latestBattleLog = "";
    private readonly List<string> fullBattleLogs = new List<string>();

    public string LatestBattleLog => latestBattleLog;
    public IReadOnlyList<string> FullBattleLogs => fullBattleLogs;

    public void ClearBattleLog()
    {
        latestBattleLog = "";
        fullBattleLogs.Clear();
        RefreshBattleLogUI();
        RefreshPopupBattleLogUI();
    }

    public void AppendBattleLog(string message)
    {
        if (string.IsNullOrEmpty(message))
            return;

        latestBattleLog = message;
        fullBattleLogs.Add(message);

        RefreshBattleLogUI();
        RefreshPopupBattleLogUI();
    }

    public void RefreshBattleLogUI()
    {
        if (battleLogText != null)
            battleLogText.text = latestBattleLog;
    }

    public void RefreshPopupBattleLogUI()
    {
        if (popupLogText != null)
            popupLogText.text = string.Join("\n", fullBattleLogs);

        Canvas.ForceUpdateCanvases();

        if (popupLogScrollRect != null)
            popupLogScrollRect.verticalNormalizedPosition = 0f;
    }

    public string FormatTurnLog(int round)
    {
        return $"<color={turnColor}>Turn{round}</color>";
    }

    public string FormatUnitName(string unitName)
    {
        return $"<color={unitNameColor}>{unitName}</color>";
    }

    public string FormatDefaultText(string text)
    {
        return $"<color={defaultTextColor}>{text}</color>";
    }

    public string FormatDamageValueOnlyNumber(int value)
    {
        return $"<color={damageColor}>{value}</color>";
    }

    public string FormatHealValueOnlyNumber(int value)
    {
        return $"<color={healColor}>{value}</color>";
    }

    public string FormatBuffValueOnlyNumber(int value)
    {
        return $"<color={buffColor}>{value}</color>";
    }

    public string FormatDamageKeyword()
    {
        return $"<color={damageColor}>������</color>";
    }

    public string FormatHealKeyword()
    {
        return $"<color={healColor}>ȸ��</color>";
    }

    public string FormatShieldKeyword()
    {
        return $"<color={buffColor}>��ȣ��</color>";
    }

    public string FormatBuffKeyword(string buffName)
    {
        return $"<color={buffColor}>{buffName}</color>";
    }

    public string BuildAttackLog(BattleUnit attacker, BattleUnit target, string skillName, AttackResult result)
    {
        string attackerName = FormatUnitName(attacker.Name);
        string targetName = FormatUnitName(target.Name);

        string actionText = string.IsNullOrEmpty(skillName)
            ? ""
            : $"{FormatDefaultText(skillName)} ";

        switch (result.ResultType)
        {
            case AttackResultType.Crit:
                return $"{attackerName}�� {targetName}���� {actionText}{FormatDefaultText("ġ��Ÿ��")} {FormatDamageValueOnlyNumber(result.Damage)} {FormatDamageKeyword()}�� {FormatDefaultText("�������ϴ�")}";

            case AttackResultType.Hit:
                return $"{attackerName}�� {targetName}���� {actionText}{FormatDamageValueOnlyNumber(result.Damage)} {FormatDamageKeyword()}�� {FormatDefaultText("�������ϴ�")}";

            case AttackResultType.Graze:
                return $"{attackerName}�� {targetName}���� {actionText}{FormatDefaultText("��ħ����")} {FormatDamageValueOnlyNumber(result.Damage)} {FormatDamageKeyword()}�� {FormatDefaultText("�������ϴ�")}";

            case AttackResultType.Miss:
                return $"{attackerName}�� {targetName}���� {actionText}{FormatDefaultText("���������� ���������ϴ�")}";
        }

        return $"{attackerName}�� {targetName}���� {FormatDefaultText("�����߽��ϴ�")}";
    }

    public string BuildItemHealLog(BattleUnit user, BattleUnit target, string actionText, int value)
    {
        return $"{FormatUnitName(user.Name)}�� {FormatUnitName(target.Name)}���� {FormatDefaultText(actionText)} {FormatHealValueOnlyNumber(value)} {FormatHealKeyword()}�� {FormatDefaultText("ȸ�����׽��ϴ�")}";
    }

    public string BuildBuffLog(BattleUnit user, BattleUnit target, string actionText, int value, string buffText)
    {
        return $"{FormatUnitName(user.Name)}�� {FormatUnitName(target.Name)}���� {FormatDefaultText(actionText)} {FormatBuffValueOnlyNumber(value)} {FormatBuffKeyword(buffText)}�� {FormatDefaultText("�ο��߽��ϴ�")}";
    }

    public string BuildShieldLog(BattleUnit user, BattleUnit target, string actionText, int value)
    {
        return $"{FormatUnitName(user.Name)}�� {FormatUnitName(target.Name)}���� {FormatDefaultText(actionText)} {FormatBuffValueOnlyNumber(value)} {FormatShieldKeyword()}�� {FormatDefaultText("�ο��߽��ϴ�")}";
    }

    public string BuildMoveLog(BattleUnit user, BattleUnit target)
    {
        return $"{FormatUnitName(user.Name)}�� {FormatUnitName(target.Name)}�� {FormatDefaultText("��ġ�� ��ü�߽��ϴ�")}";
    }

    public string BuildAutoMoveLog(BattleUnit user)
    {
        return $"{FormatUnitName(user.Name)}�� {FormatDefaultText("��ġ�� �̵��߽��ϴ�")}";
    }

    public string BuildDeathLog(BattleUnit target)
    {
        return $"{FormatUnitName(target.Name)}�� {FormatDefaultText("����߽��ϴ�")}";
    }

    public string BuildBattleStartLog()
    {
        return FormatDefaultText("������ ���۵Ǿ����ϴ�");
    }

    public string BuildVictoryLog()
    {
        return FormatDefaultText("�������� �¸��߽��ϴ�");
    }

    public string BuildDefeatLog()
    {
        return FormatDefaultText("�������� �й��߽��ϴ�");
    }
}