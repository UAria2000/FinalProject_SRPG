using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(CanvasGroup))]
public class PartyEquipmentSlotUI : MonoBehaviour,
    IPointerClickHandler,
    IDropHandler,
    IBeginDragHandler,
    IEndDragHandler
{
    [SerializeField] private Image iconImage;

    private BottomPartySummaryPanelUI owner;
    private CanvasGroup canvasGroup;

    public PartyMemberData Member { get; private set; }
    public int SlotIndex { get; private set; }
    public ItemDefinition AssignedItem { get; private set; }

    private void Awake()
    {
        canvasGroup = GetComponent<CanvasGroup>();
    }

    public void Bind(
        BottomPartySummaryPanelUI panelOwner,
        PartyMemberData member,
        int slotIndex,
        ItemDefinition assignedItem,
        bool visible)
    {
        owner = panelOwner;
        Member = member;
        SlotIndex = Mathf.Clamp(slotIndex, 0, 1);
        AssignedItem = assignedItem;

        gameObject.SetActive(visible);

        bool hasItem = AssignedItem != null;
        if (iconImage != null)
        {
            iconImage.gameObject.SetActive(hasItem);
            iconImage.sprite = hasItem ? AssignedItem.icon : null;
        }
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (eventData.button != PointerEventData.InputButton.Left)
            return;

        owner?.HandleEquipmentSlotClicked(this);
    }

    public void OnDrop(PointerEventData eventData)
    {
        owner?.HandleEquipmentSlotDropped(this);
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        if (eventData.button != PointerEventData.InputButton.Left || AssignedItem == null || owner == null)
            return;

        canvasGroup.blocksRaycasts = false;
        owner.BeginEquipmentDrag(this);
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        canvasGroup.blocksRaycasts = true;
        owner?.EndEquipmentDrag(this);
    }
}