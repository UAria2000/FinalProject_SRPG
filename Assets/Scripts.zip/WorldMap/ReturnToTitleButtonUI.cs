using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ReturnToTitleButtonUI : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Button titleButton;
    [SerializeField] private GameObject settingsPanelRoot;
    [SerializeField] private SaveCoordinator saveCoordinator;

    [Header("Scene")]
    [SerializeField] private string bootstrapSceneName = "Bootstrap";

    private void Awake()
    {
        if (saveCoordinator == null)
            saveCoordinator = SaveCoordinator.Instance;

        if (titleButton != null)
        {
            titleButton.onClick.RemoveAllListeners();
            titleButton.onClick.AddListener(HandleReturnToTitleClicked);
        }
    }

    private void HandleReturnToTitleClicked()
    {
        if (saveCoordinator == null)
            saveCoordinator = SaveCoordinator.Instance;

        // ����â ���� �ݱ�
        if (settingsPanelRoot != null)
            settingsPanelRoot.SetActive(false);

        // ���� ������ + ���� ���� ����
        saveCoordinator?.SaveAll();

        // Ÿ��Ʋ(bootstrap) ������ �̵�
        SceneManager.LoadScene(bootstrapSceneName);
    }
}