using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class CorruptSlot : MonoBehaviour, IDropHandler, IPointerEnterHandler, IPointerExitHandler
{
    [Header("UI References")]
    [SerializeField] private Image portraitDisplay;
    [SerializeField] private GameObject emptyVisual;
    [SerializeField] private GameObject cancelOverlay;
    [SerializeField] private Button cancelButton;

    private PrisonerData currentPrisoner;

    void Awake()
    {
        if (cancelButton != null) cancelButton.onClick.AddListener(CancelCorruption);
        if (cancelOverlay != null) cancelOverlay.SetActive(false);
        if (portraitDisplay != null) portraitDisplay.gameObject.SetActive(false);
    }

    public void OnDrop(PointerEventData eventData)
    {
        if (eventData.pointerDrag != null)
        {
            ItemSlot draggedSlot = eventData.pointerDrag.GetComponent<ItemSlot>();

            if (draggedSlot != null && draggedSlot.myData != null && currentPrisoner == null)
            {
                currentPrisoner = draggedSlot.myData;
                currentPrisoner.isCorrupting = true;

                if (portraitDisplay != null)
                {
                    portraitDisplay.sprite = currentPrisoner.portrait;
                    portraitDisplay.gameObject.SetActive(true);

                    RectTransform rect = portraitDisplay.GetComponent<RectTransform>();

                    // 1. �ǹ��� ��Ŀ�� ��� �߾����� Ȯ���� ����!
                    rect.pivot = new Vector2(0.5f, 1f);
                    rect.anchorMin = new Vector2(0.5f, 1f);
                    rect.anchorMax = new Vector2(0.5f, 1f);
                    rect.anchoredPosition = Vector2.zero;

                    // 2. �ϴ� ���� ũ��� Ű�� ����...
                    portraitDisplay.SetNativeSize();

                    // 3. �� �ٽ�: �������� ����ũ(�θ�)���� �۰ų� �ʹ� ũ�� �� �Ǵϱ� �������� ����!
                    // �θ�(PortraitMask)�� �ʺ� �����ͼ� �� �ʺ�� �����ؿ�.
                    float parentWidth = rect.parent.GetComponent<RectTransform>().rect.width;
                    float ratio = parentWidth / rect.sizeDelta.x;
                    rect.sizeDelta = new Vector2(parentWidth, rect.sizeDelta.y * ratio);
                }

                if (emptyVisual != null) emptyVisual.SetActive(false);

                Destroy(eventData.pointerDrag);

                PrisonerManager.Instance.OnPrisonerListChanged?.Invoke();
                Debug.Log($"{currentPrisoner.prisonerName} Ÿ�� ����, ����!");
            }
        }
    }

    // --- ���콺 ���� �� ��� ������ ������ ���� ---
    public void OnPointerEnter(PointerEventData eventData)
    {
        if (currentPrisoner != null && cancelOverlay != null) cancelOverlay.SetActive(true);
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (cancelOverlay != null) cancelOverlay.SetActive(false);
    }

    public void CancelCorruption()
    {
        if (currentPrisoner == null) return;
        currentPrisoner.isCorrupting = false;
        currentPrisoner = null;
        if (portraitDisplay != null) portraitDisplay.gameObject.SetActive(false);
        if (emptyVisual != null) emptyVisual.SetActive(true);
        if (cancelOverlay != null) cancelOverlay.SetActive(false);
        PrisonerManager.Instance.OnPrisonerListChanged?.Invoke();
    }
}