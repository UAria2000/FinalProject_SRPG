using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class CorruptUI : MonoBehaviour
{
    [Header("Left Slots (Status)")]
    [SerializeField] private List<CorruptSlot> statusSlots;

    [Header("Right Inventory Settings")]
    [SerializeField] private GameObject itemSlotPrefab; // Prisoners_Prefab ����
    [SerializeField] private Transform contentParent;
    [SerializeField] private int totalSlots = 32;

    void OnEnable()
    {
        if (PrisonerManager.Instance != null)
        {
            PrisonerManager.Instance.OnPrisonerListChanged += RefreshInventory;
        }
        RefreshInventory();
    }

    void OnDisable()
    {
        if (PrisonerManager.Instance != null)
        {
            PrisonerManager.Instance.OnPrisonerListChanged -= RefreshInventory;
        }
    }

    public void RefreshInventory()
    {
        // ���� ���� ����
        foreach (Transform child in contentParent) Destroy(child.gameObject);

        // Ÿ�� ���� �ƴ� ���� ������ ����
        var availablePrisoners = PrisonerManager.Instance.allPrisoners
            .Where(p => !p.isCorrupting)
            .ToList();

        for (int i = 0; i < totalSlots; i++)
        {
            GameObject slotObj = Instantiate(itemSlotPrefab, contentParent);
            ItemSlot slotScript = slotObj.GetComponent<ItemSlot>();

            if (slotScript != null)
            {
                // ù ��(index 0~7)�� �ڹ��� ���� �� �巡�� ���
                bool isLocked = (i >= 8);
                slotScript.SetLocked(isLocked);
                slotScript.canDrag = !isLocked;
                slotScript.enabled = true;

                // �����Ͱ� �����ϴ� ��쿡�� UI ����
                if (i < availablePrisoners.Count)
                {
                    var data = availablePrisoners[i];
                    slotScript.myData = data;
                    slotScript.SetItem(data.portrait);
                    slotObj.name = $"CorruptInvSlot_{i} ({data.prisonerName})";
                }
                else
                {
                    slotScript.myData = null;
                    slotScript.SetItem(null);
                    slotObj.name = $"CorruptInvSlot_{i} (Empty)";
                }
            }
        }
    }
}